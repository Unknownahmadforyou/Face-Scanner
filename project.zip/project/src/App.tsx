import { useEffect, lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';
import ProtectedRoute from './components/shared/ProtectedRoute';
import AppLayout from './components/layouts/AppLayout';
import AuthLayout from './components/layouts/AuthLayout';
import LoadingScreen from './components/shared/LoadingScreen';

// Lazy-loaded components
const Login = lazy(() => import('./pages/auth/Login'));
const Register = lazy(() => import('./pages/auth/Register'));
const Dashboard = lazy(() => import('./pages/dashboard/Dashboard'));
const MarkAttendance = lazy(() => import('./pages/attendance/MarkAttendance'));
const AttendanceHistory = lazy(() => import('./pages/attendance/AttendanceHistory'));
const StudentManagement = lazy(() => import('./pages/admin/StudentManagement'));
const ClassManagement = lazy(() => import('./pages/admin/ClassManagement'));
const Reports = lazy(() => import('./pages/admin/Reports'));
const Profile = lazy(() => import('./pages/profile/Profile'));
const NotFound = lazy(() => import('./pages/NotFound'));

function App() {
  const { initializeAuth, isInitializing } = useAuthStore();

  useEffect(() => {
    initializeAuth();
  }, [initializeAuth]);

  if (isInitializing) {
    return <LoadingScreen />;
  }

  return (
    <Suspense fallback={<LoadingScreen />}>
      <Routes>
        {/* Auth Routes */}
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Route>

        {/* Protected App Routes */}
        <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/mark-attendance" element={<MarkAttendance />} />
          <Route path="/attendance-history" element={<AttendanceHistory />} />
          <Route path="/admin/students" element={<StudentManagement />} />
          <Route path="/admin/classes" element={<ClassManagement />} />
          <Route path="/admin/reports" element={<Reports />} />
          <Route path="/profile" element={<Profile />} />
        </Route>

        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}

export default App;