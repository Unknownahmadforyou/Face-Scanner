import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '../navigation/Sidebar';
import Header from '../navigation/Header';

function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar open={sidebarOpen} setOpen={setSidebarOpen} />
      
      <div className="flex flex-1 flex-col">
        <Header setSidebarOpen={setSidebarOpen} />
        
        <main className="flex-1 p-4 md:p-6">
          <div className="mx-auto max-w-7xl">
            <Outlet />
          </div>
        </main>
        
        <footer className="border-t border-gray-200 bg-white py-4 text-center text-sm text-gray-500">
          <p>© {new Date().getFullYear()} EduTrack. All rights reserved.</p>
        </footer>
      </div>
    </div>
  );
}

export default AppLayout;