import { Outlet } from 'react-router-dom';
import { BookOpen } from 'lucide-react';

function AuthLayout() {
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* Left side - branding */}
      <div className="hidden bg-primary-600 md:flex md:w-1/2 md:flex-col md:items-center md:justify-center">
        <div className="max-w-md p-8 text-center text-white">
          <BookOpen className="mx-auto mb-6 h-16 w-16" />
          <h1 className="mb-4 text-4xl font-bold">EduTrack</h1>
          <p className="mb-6 text-lg leading-relaxed text-white/90">
            A modern attendance management system with facial recognition technology
            for educational institutions.
          </p>
          <div className="mx-auto h-1 w-16 bg-white/30"></div>
        </div>
      </div>

      {/* Right side - auth form */}
      <div className="flex w-full items-center justify-center bg-white p-4 md:w-1/2 md:p-0">
        <div className="w-full max-w-md space-y-8 p-6">
          <div className="text-center md:hidden">
            <BookOpen className="mx-auto mb-2 h-10 w-10 text-primary-600" />
            <h1 className="text-2xl font-bold text-gray-900">EduTrack</h1>
          </div>
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default AuthLayout;