import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

interface AuthState {
  user: User | null;
  isInitializing: boolean;
  initializeAuth: () => Promise<void>;
  login: (email: string, password: string) => Promise<{ error: any | null }>;
  register: (email: string, password: string, userData: any) => Promise<{ error: any | null }>;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isInitializing: true,
  
  initializeAuth: async () => {
    const { data } = await supabase.auth.getSession();
    
    if (data.session) {
      const { data: userData } = await supabase.auth.getUser();
      set({ user: userData.user, isInitializing: false });
    } else {
      set({ user: null, isInitializing: false });
    }
    
    // Setup auth state change listener
    supabase.auth.onAuthStateChange((_event, session) => {
      set({ user: session?.user || null });
    });
  },
  
  login: async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error };
  },
  
  register: async (email, password, userData) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: userData,
      },
    });
    return { error };
  },
  
  logout: async () => {
    await supabase.auth.signOut();
    set({ user: null });
  },
}));