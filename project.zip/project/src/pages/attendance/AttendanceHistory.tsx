import { useState, useEffect } from 'react';
import { Calendar, Filter, Download, ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface AttendanceRecord {
  id: string;
  date: string;
  course: string;
  status: 'present' | 'absent' | 'late';
  time: string;
}

function AttendanceHistory() {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  useEffect(() => {
    // In a real app, this would fetch from Supabase
    const fetchAttendanceRecords = async () => {
      setLoading(true);
      
      // Simulated data
      setTimeout(() => {
        const sampleData: AttendanceRecord[] = [
          {
            id: '1',
            date: '2025-01-15',
            course: 'Computer Science 101',
            status: 'present',
            time: '09:15 AM',
          },
          {
            id: '2',
            date: '2025-01-15',
            course: 'Mathematics 202',
            status: 'present',
            time: '11:05 AM',
          },
          {
            id: '3',
            date: '2025-01-16',
            course: 'Physics 101',
            status: 'absent',
            time: '02:00 PM',
          },
          {
            id: '4',
            date: '2025-01-17',
            course: 'English Literature',
            status: 'late',
            time: '10:10 AM',
          },
          {
            id: '5',
            date: '2025-01-18',
            course: 'Computer Science 101',
            status: 'present',
            time: '09:05 AM',
          },
          {
            id: '6',
            date: '2025-01-19',
            course: 'History 101',
            status: 'present',
            time: '01:00 PM',
          },
          {
            id: '7',
            date: '2025-01-20',
            course: 'Mathematics 202',
            status: 'absent',
            time: '11:00 AM',
          },
        ];
        
        setRecords(sampleData);
        setLoading(false);
      }, 800);
    };
    
    fetchAttendanceRecords();
  }, []);
  
  const filteredRecords = records.filter(record => {
    // Filter by status
    if (filter !== 'all' && record.status !== filter) {
      return false;
    }
    
    // Filter by selected date if any
    if (selectedDate) {
      const recordDate = new Date(record.date);
      if (
        recordDate.getDate() !== selectedDate.getDate() ||
        recordDate.getMonth() !== selectedDate.getMonth() ||
        recordDate.getFullYear() !== selectedDate.getFullYear()
      ) {
        return false;
      }
    }
    
    // Filter by search query
    if (searchQuery) {
      return record.course.toLowerCase().includes(searchQuery.toLowerCase());
    }
    
    return true;
  });
  
  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };
  
  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };
  
  const handleDateClick = (date: Date) => {
    if (selectedDate && 
        date.getDate() === selectedDate.getDate() && 
        date.getMonth() === selectedDate.getMonth() && 
        date.getFullYear() === selectedDate.getFullYear()) {
      setSelectedDate(null);
    } else {
      setSelectedDate(date);
    }
  };
  
  const renderCalendar = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    // Get first day of month and last day
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    // Get day of week for first day (0-6, Sun-Sat)
    const firstDayIndex = firstDay.getDay();
    
    // Get days in month
    const daysInMonth = lastDay.getDate();
    
    // Days of week headers
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    // Create calendar grid
    const days = [];
    
    // Add empty cells for days before first day of month
    for (let i = 0; i < firstDayIndex; i++) {
      days.push(<div key={`empty-${i}`} className="h-8 w-8"></div>);
    }
    
    // Add cells for each day of month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      
      // Check if there's attendance for this day
      const hasPresent = records.some(record => {
        const recordDate = new Date(record.date);
        return (
          recordDate.getDate() === day &&
          recordDate.getMonth() === month &&
          recordDate.getFullYear() === year &&
          record.status === 'present'
        );
      });
      
      const hasAbsent = records.some(record => {
        const recordDate = new Date(record.date);
        return (
          recordDate.getDate() === day &&
          recordDate.getMonth() === month &&
          recordDate.getFullYear() === year &&
          record.status === 'absent'
        );
      });
      
      const hasLate = records.some(record => {
        const recordDate = new Date(record.date);
        return (
          recordDate.getDate() === day &&
          recordDate.getMonth() === month &&
          recordDate.getFullYear() === year &&
          record.status === 'late'
        );
      });
      
      // Check if this day is selected
      const isSelected = selectedDate && 
        selectedDate.getDate() === day && 
        selectedDate.getMonth() === month && 
        selectedDate.getFullYear() === year;
      
      // Check if this is today
      const isToday = new Date().toDateString() === date.toDateString();
      
      days.push(
        <div 
          key={`day-${day}`} 
          className={`
            relative flex h-8 w-8 cursor-pointer items-center justify-center rounded-full
            ${isSelected ? 'bg-primary-600 text-white' : ''}
            ${isToday && !isSelected ? 'border border-primary-600 font-bold' : ''}
          `}
          onClick={() => handleDateClick(date)}
        >
          {day}
          <div className="absolute -bottom-1 flex h-1 space-x-0.5">
            {hasPresent && <span className="h-1 w-1 rounded-full bg-green-500"></span>}
            {hasAbsent && <span className="h-1 w-1 rounded-full bg-red-500"></span>}
            {hasLate && <span className="h-1 w-1 rounded-full bg-amber-500"></span>}
          </div>
        </div>
      );
    }
    
    return (
      <div className="mt-2">
        <div className="mb-4 flex items-center justify-between">
          <button
            onClick={handlePrevMonth}
            className="rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-500"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <h3 className="text-sm font-medium text-gray-900">
            {currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </h3>
          <button
            onClick={handleNextMonth}
            className="rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-500"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
        
        <div className="grid grid-cols-7 gap-y-2 text-center text-xs">
          {daysOfWeek.map(day => (
            <div key={day} className="font-medium text-gray-500">
              {day}
            </div>
          ))}
          {days}
        </div>
        
        <div className="mt-4 flex justify-center space-x-4 text-xs">
          <div className="flex items-center">
            <span className="mr-1 h-2 w-2 rounded-full bg-green-500"></span>
            <span className="text-gray-600">Present</span>
          </div>
          <div className="flex items-center">
            <span className="mr-1 h-2 w-2 rounded-full bg-red-500"></span>
            <span className="text-gray-600">Absent</span>
          </div>
          <div className="flex items-center">
            <span className="mr-1 h-2 w-2 rounded-full bg-amber-500"></span>
            <span className="text-gray-600">Late</span>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Attendance History</h1>
        
        <button className="btn btn-outline">
          <Download className="mr-2 h-4 w-4" />
          Export
        </button>
      </div>
      
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
        {/* Calendar and filters */}
        <div className="lg:col-span-1">
          <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
            <div className="flex items-center text-sm font-medium text-gray-700">
              <Calendar className="mr-2 h-4 w-4 text-primary-500" />
              <h2>Calendar</h2>
            </div>
            
            {renderCalendar()}
            
            <div className="mt-6 space-y-4">
              <div>
                <h3 className="mb-2 flex items-center text-sm font-medium text-gray-700">
                  <Filter className="mr-2 h-4 w-4 text-primary-500" />
                  Filters
                </h3>
                
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="status"
                      checked={filter === 'all'}
                      onChange={() => setFilter('all')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">All</span>
                  </label>
                  
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="status"
                      checked={filter === 'present'}
                      onChange={() => setFilter('present')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Present</span>
                  </label>
                  
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="status"
                      checked={filter === 'absent'}
                      onChange={() => setFilter('absent')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Absent</span>
                  </label>
                  
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="status"
                      checked={filter === 'late'}
                      onChange={() => setFilter('late')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Late</span>
                  </label>
                </div>
              </div>
              
              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">
                  Search by Course
                </label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="input pl-10"
                    placeholder="Search courses..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Attendance records */}
        <div className="lg:col-span-3">
          <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
            <div className="p-4">
              <h2 className="text-lg font-medium text-gray-900">Attendance Records</h2>
              <p className="text-sm text-gray-500">
                {selectedDate ? (
                  `Showing records for ${selectedDate.toLocaleDateString('en-US', { 
                    month: 'long', 
                    day: 'numeric', 
                    year: 'numeric' 
                  })}`
                ) : (
                  'Showing all attendance records'
                )}
              </p>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Course
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Time
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                      Status
                    </th>
                  </tr>
                </thead>
                
                <tbody className="divide-y divide-gray-200 bg-white">
                  {loading ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                        Loading records...
                      </td>
                    </tr>
                  ) : filteredRecords.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                        No records found.
                      </td>
                    </tr>
                  ) : (
                    filteredRecords.map((record) => (
                      <tr key={record.id}>
                        <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                          {new Date(record.date).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </td>
                        <td className="px-6 py-4 text-sm font-medium text-gray-900">
                          {record.course}
                        </td>
                        <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-500">
                          {record.time}
                        </td>
                        <td className="whitespace-nowrap px-6 py-4 text-sm">
                          {record.status === 'present' && (
                            <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                              Present
                            </span>
                          )}
                          {record.status === 'absent' && (
                            <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800">
                              Absent
                            </span>
                          )}
                          {record.status === 'late' && (
                            <span className="inline-flex items-center rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-800">
                              Late
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            
            <div className="border-t border-gray-200 bg-gray-50 px-4 py-3 text-right text-sm">
              <span className="text-gray-700">
                Showing <span className="font-medium">{filteredRecords.length}</span> records
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AttendanceHistory;