import { useEffect, useState, useRef } from 'react';
import { Camera, Loader2, Check, X, RefreshCw } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import { supabase } from '../../lib/supabase';
import { loadModels, startWebcam, stopWebcam, getFaceDescriptors } from '../../utils/faceRecognition';

function MarkAttendance() {
  const { user } = useAuthStore();
  const [status, setStatus] = useState<'idle' | 'loading' | 'ready' | 'detecting' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const [video, setVideo] = useState<HTMLVideoElement | null>(null);
  const videoRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [errorDetails, setErrorDetails] = useState('');
  
  // Initialize face recognition
  useEffect(() => {
    const initFaceRecognition = async () => {
      try {
        setStatus('loading');
        setMessage('Loading face recognition models...');
        await loadModels();
        setStatus('ready');
        setMessage('Face recognition ready. Click "Start Camera" to begin.');
      } catch (error) {
        console.error('Failed to initialize face recognition:', error);
        setStatus('error');
        setMessage('Failed to load face recognition models.');
        setErrorDetails('Please make sure you have a stable internet connection and try again.');
      }
    };

    initFaceRecognition();
    
    // Cleanup on unmount
    return () => {
      if (video) {
        stopWebcam(video);
      }
    };
  }, []);

  const handleStartCamera = async () => {
    try {
      setStatus('loading');
      setMessage('Accessing webcam...');
      
      const webcam = await startWebcam();
      setVideo(webcam);
      
      if (videoRef.current) {
        videoRef.current.innerHTML = '';
        videoRef.current.appendChild(webcam);
      }
      
      setStatus('ready');
      setMessage('Camera ready. Position your face within the frame and click "Detect Face".');
    } catch (error) {
      console.error('Error starting webcam:', error);
      setStatus('error');
      setMessage('Failed to access webcam.');
      setErrorDetails('Please ensure your camera is connected and you have granted camera permissions.');
    }
  };

  const handleStopCamera = () => {
    if (video) {
      stopWebcam(video);
      setVideo(null);
      
      if (videoRef.current) {
        videoRef.current.innerHTML = '';
      }
      
      setStatus('idle');
      setMessage('');
    }
  };

  const handleDetectFace = async () => {
    if (!video || !canvasRef.current) return;
    
    try {
      setStatus('detecting');
      setMessage('Detecting face...');
      
      // Draw current video frame to canvas for processing
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      }
      
      // Get face descriptors
      const detections = await getFaceDescriptors(video);
      
      if (detections.length === 0) {
        setStatus('error');
        setMessage('No face detected.');
        setErrorDetails('Please ensure your face is clearly visible in the frame and try again.');
        return;
      }
      
      if (detections.length > 1) {
        setStatus('error');
        setMessage('Multiple faces detected.');
        setErrorDetails('Please ensure only one person is in the frame and try again.');
        return;
      }
      
      // In a real app, you would compare the detected face with stored face descriptors
      // Here, we'll simulate a successful match
      
      // Simulate a slight delay for face matching
      setTimeout(async () => {
        // Record attendance in Supabase (placeholder)
        // In a real app, you would store the attendance record in your database
        
        try {
          setStatus('success');
          setMessage('Attendance marked successfully.');
          
          // Auto-close after a few seconds
          setTimeout(() => {
            handleStopCamera();
            setStatus('idle');
          }, 3000);
        } catch (error) {
          console.error('Error recording attendance:', error);
          setStatus('error');
          setMessage('Failed to record attendance.');
          setErrorDetails('There was a problem saving your attendance record. Please try again.');
        }
      }, 1500);
      
    } catch (error) {
      console.error('Error detecting face:', error);
      setStatus('error');
      setMessage('Face detection failed.');
      setErrorDetails('There was a problem processing your image. Please try again.');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Mark Attendance</h1>
      </div>
      
      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-center space-x-2">
          <Camera className="h-5 w-5 text-primary-600" />
          <h2 className="text-lg font-medium text-gray-900">Facial Recognition</h2>
        </div>
        
        <p className="mb-6 text-gray-600">
          Please position your face clearly in the camera frame to mark your attendance.
          The system will automatically verify your identity.
        </p>
        
        {status === 'error' && (
          <div className="mb-4 rounded-md border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <div className="flex items-center">
              <X className="mr-2 h-5 w-5 text-red-500" />
              <span className="font-medium">{message}</span>
            </div>
            {errorDetails && <p className="mt-1 pl-7">{errorDetails}</p>}
          </div>
        )}
        
        {status === 'success' && (
          <div className="mb-4 rounded-md border border-green-200 bg-green-50 p-4 text-sm text-green-700">
            <div className="flex items-center">
              <Check className="mr-2 h-5 w-5 text-green-500" />
              <span className="font-medium">{message}</span>
            </div>
          </div>
        )}
        
        <div className="mb-6 rounded-lg bg-gray-100 p-4">
          <div 
            ref={videoRef} 
            className="relative mx-auto flex h-[320px] max-w-md items-center justify-center overflow-hidden rounded-lg bg-gray-900"
          >
            {!video && status !== 'loading' && (
              <div className="flex flex-col items-center text-gray-400">
                <Camera className="mb-2 h-10 w-10" />
                <p>Camera not started</p>
              </div>
            )}
            
            {status === 'loading' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/60 text-white">
                <Loader2 className="mb-2 h-8 w-8 animate-spin" />
                <p>{message}</p>
              </div>
            )}
            
            {status === 'detecting' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/60 text-white">
                <Loader2 className="mb-2 h-8 w-8 animate-spin" />
                <p>{message}</p>
              </div>
            )}
          </div>
          
          {/* Hidden canvas for image processing */}
          <canvas ref={canvasRef} className="hidden"></canvas>
          
          <div className="mt-4 flex justify-center space-x-4">
            {!video ? (
              <button 
                onClick={handleStartCamera}
                disabled={status === 'loading'}
                className="btn btn-primary"
              >
                {status === 'loading' ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Starting Camera...</>
                ) : (
                  'Start Camera'
                )}
              </button>
            ) : (
              <>
                <button 
                  onClick={handleDetectFace}
                  disabled={status === 'detecting'}
                  className="btn btn-primary"
                >
                  {status === 'detecting' ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Detecting...</>
                  ) : (
                    'Detect Face'
                  )}
                </button>
                
                <button 
                  onClick={handleStopCamera}
                  className="btn btn-outline"
                >
                  Stop Camera
                </button>
              </>
            )}
          </div>
        </div>
        
        <div className="rounded-md bg-gray-50 p-4 text-sm">
          <h3 className="mb-2 font-medium text-gray-700">Instructions:</h3>
          <ol className="list-inside list-decimal space-y-1 text-gray-600">
            <li>Click "Start Camera" to enable your webcam</li>
            <li>Position your face clearly in the frame</li>
            <li>Ensure good lighting and remove any obstructions</li>
            <li>Click "Detect Face" to verify your identity and mark attendance</li>
          </ol>
        </div>
        
        <div className="mt-4 text-center text-xs text-gray-500">
          <p>Having trouble? Try refreshing the page or contact support.</p>
        </div>
      </div>
      
      <div className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
        <h2 className="mb-4 text-lg font-medium text-gray-900">Today's Attendance Status</h2>
        
        <div className="overflow-hidden rounded-lg border border-gray-200">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Course
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Time
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              <tr>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="text-sm font-medium text-gray-900">Computer Science 101</div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="text-sm text-gray-500">09:00 - 10:30 AM</div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <span className="inline-flex rounded-full bg-green-100 px-2 text-xs font-semibold leading-5 text-green-800">
                    Present
                  </span>
                </td>
              </tr>
              <tr>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="text-sm font-medium text-gray-900">Mathematics 202</div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="text-sm text-gray-500">11:00 - 12:30 PM</div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <span className="inline-flex rounded-full bg-yellow-100 px-2 text-xs font-semibold leading-5 text-yellow-800">
                    Pending
                  </span>
                </td>
              </tr>
              <tr>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="text-sm font-medium text-gray-900">Physics 101</div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <div className="text-sm text-gray-500">02:00 - 03:30 PM</div>
                </td>
                <td className="whitespace-nowrap px-6 py-4">
                  <span className="inline-flex rounded-full bg-yellow-100 px-2 text-xs font-semibold leading-5 text-yellow-800">
                    Pending
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 flex justify-center">
          <button className="btn btn-outline">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh Status
          </button>
        </div>
      </div>
    </div>
  );
}

export default MarkAttendance;