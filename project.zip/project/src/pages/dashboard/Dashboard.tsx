import { useEffect, useState } from 'react';
import { useAuthStore } from '../../stores/authStore';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Users, 
  BookOpen,
  CalendarCheck,
  BarChart2
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend 
} from 'recharts';

function Dashboard() {
  const { user } = useAuthStore();
  const [stats, setStats] = useState({
    totalAttendance: 0,
    presentCount: 0,
    absentCount: 0,
    lateCount: 0,
    totalStudents: 0,
    totalCourses: 0,
  });
  const [attendanceData, setAttendanceData] = useState([]);
  const [weeklyData, setWeeklyData] = useState([]);
  const [loading, setLoading] = useState(true);
  const isAdmin = user?.user_metadata?.role === 'admin';

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Get attendance summary
        // This is a placeholder - in a real app, you would fetch from your database
        
        // Simulated data while waiting for Supabase connection
        setTimeout(() => {
          // Simulated statistics
          setStats({
            totalAttendance: 157,
            presentCount: 128,
            absentCount: 18,
            lateCount: 11,
            totalStudents: 42,
            totalCourses: 5,
          });
          
          // Simulated attendance data by course
          setAttendanceData([
            { name: 'Computer Science', present: 92, absent: 8 },
            { name: 'Mathematics', present: 85, absent: 15 },
            { name: 'Physics', present: 78, absent: 22 },
            { name: 'English', present: 88, absent: 12 },
            { name: 'History', present: 72, absent: 28 },
          ]);
          
          // Simulated weekly attendance data
          setWeeklyData([
            { day: 'Mon', present: 38, absent: 4 },
            { day: 'Tue', present: 40, absent: 2 },
            { day: 'Wed', present: 35, absent: 7 },
            { day: 'Thu', present: 37, absent: 5 },
            { day: 'Fri', present: 42, absent: 0 },
          ]);
          
          setLoading(false);
        }, 800);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [user]);

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <div className="text-sm font-medium text-gray-500">
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="card">
          <div className="flex justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Present</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.presentCount}</p>
            </div>
            <div className="rounded-full bg-green-100 p-3 text-green-600">
              <CheckCircle2 className="h-6 w-6" />
            </div>
          </div>
          <div className="mt-2 text-xs font-medium text-gray-500">
            {stats.totalAttendance > 0 ? 
              `${Math.round((stats.presentCount / stats.totalAttendance) * 100)}%` : '0%'} of total
          </div>
        </div>

        <div className="card">
          <div className="flex justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Absent</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.absentCount}</p>
            </div>
            <div className="rounded-full bg-red-100 p-3 text-red-600">
              <XCircle className="h-6 w-6" />
            </div>
          </div>
          <div className="mt-2 text-xs font-medium text-gray-500">
            {stats.totalAttendance > 0 ? 
              `${Math.round((stats.absentCount / stats.totalAttendance) * 100)}%` : '0%'} of total
          </div>
        </div>

        <div className="card">
          <div className="flex justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Late</p>
              <p className="text-2xl font-semibold text-gray-900">{stats.lateCount}</p>
            </div>
            <div className="rounded-full bg-amber-100 p-3 text-amber-600">
              <Clock className="h-6 w-6" />
            </div>
          </div>
          <div className="mt-2 text-xs font-medium text-gray-500">
            {stats.totalAttendance > 0 ? 
              `${Math.round((stats.lateCount / stats.totalAttendance) * 100)}%` : '0%'} of total
          </div>
        </div>

        {isAdmin ? (
          <div className="card">
            <div className="flex justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Students</p>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalStudents}</p>
              </div>
              <div className="rounded-full bg-blue-100 p-3 text-blue-600">
                <Users className="h-6 w-6" />
              </div>
            </div>
            <div className="mt-2 text-xs font-medium text-gray-500">
              Across {stats.totalCourses} courses
            </div>
          </div>
        ) : (
          <div className="card">
            <div className="flex justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Courses</p>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalCourses}</p>
              </div>
              <div className="rounded-full bg-purple-100 p-3 text-purple-600">
                <BookOpen className="h-6 w-6" />
              </div>
            </div>
            <div className="mt-2 text-xs font-medium text-gray-500">
              Currently enrolled
            </div>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <div className="card cursor-pointer hover:bg-gray-50">
          <div className="flex items-center space-x-3">
            <div className="rounded-full bg-primary-100 p-3 text-primary-600">
              <Video className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-medium">Mark Attendance</h3>
              <p className="text-sm text-gray-500">Use facial recognition to mark attendance</p>
            </div>
          </div>
        </div>

        <div className="card cursor-pointer hover:bg-gray-50">
          <div className="flex items-center space-x-3">
            <div className="rounded-full bg-secondary-100 p-3 text-secondary-600">
              <CalendarCheck className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-medium">View History</h3>
              <p className="text-sm text-gray-500">Check your attendance records</p>
            </div>
          </div>
        </div>

        <div className="card cursor-pointer hover:bg-gray-50">
          <div className="flex items-center space-x-3">
            <div className="rounded-full bg-accent-100 p-3 text-accent-600">
              <BarChart2 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-medium">Reports</h3>
              <p className="text-sm text-gray-500">Generate attendance reports</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="card">
          <h3 className="mb-4 text-lg font-semibold text-gray-900">Attendance by Course</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={attendanceData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} />
                <Tooltip />
                <Legend />
                <Bar dataKey="present" stackId="a" fill="#10B981" />
                <Bar dataKey="absent" stackId="a" fill="#EF4444" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <h3 className="mb-4 text-lg font-semibold text-gray-900">Weekly Attendance</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="present" 
                  stroke="#2563EB" 
                  strokeWidth={2} 
                  activeDot={{ r: 8 }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="absent" 
                  stroke="#EF4444" 
                  strokeWidth={2} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;