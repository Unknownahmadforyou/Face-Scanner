import { createClient } from '@supabase/supabase-js';

// These values would typically come from environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase URL or Anon Key is missing. Please connect to Supabase to set up your environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);