import * as faceapi from 'face-api.js';

// Models path - assuming they will be served from the public folder
const MODEL_URL = '/models';

// Flag to track if models are loaded
let modelsLoaded = false;

/**
 * Load all required face-api.js models
 */
export async function loadModels() {
  if (modelsLoaded) return;
  
  try {
    await Promise.all([
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
    ]);
    modelsLoaded = true;
    console.log('Face recognition models loaded successfully');
  } catch (error) {
    console.error('Error loading face recognition models:', error);
    throw new Error('Failed to load face recognition models');
  }
}

/**
 * Get face descriptors from an image element
 */
export async function getFaceDescriptors(imageEl: HTMLImageElement | HTMLVideoElement) {
  if (!modelsLoaded) {
    await loadModels();
  }
  
  // Detect all faces and generate descriptors
  const detections = await faceapi
    .detectAllFaces(imageEl)
    .withFaceLandmarks()
    .withFaceDescriptors();
  
  return detections;
}

/**
 * Compare face descriptors to find matches
 */
export function findBestMatch(
  descriptor: Float32Array,
  referenceDescriptors: { label: string; descriptor: Float32Array }[]
) {
  if (referenceDescriptors.length === 0) {
    return null;
  }
  
  const faceMatcher = new faceapi.FaceMatcher(
    referenceDescriptors.map((desc) => 
      new faceapi.LabeledFaceDescriptors(desc.label, [desc.descriptor])
    )
  );
  
  return faceMatcher.findBestMatch(descriptor);
}

/**
 * Start the webcam and return the video element
 */
export async function startWebcam(): Promise<HTMLVideoElement> {
  const video = document.createElement('video');
  video.width = 640;
  video.height = 480;
  
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ 
      video: { 
        width: 640, 
        height: 480,
        facingMode: 'user'
      } 
    });
    video.srcObject = stream;
    
    return new Promise((resolve) => {
      video.onloadedmetadata = () => {
        video.play();
        resolve(video);
      };
    });
  } catch (error) {
    console.error('Error accessing webcam:', error);
    throw new Error('Could not access webcam');
  }
}

/**
 * Stop the webcam
 */
export function stopWebcam(video: HTMLVideoElement) {
  const stream = video.srcObject as MediaStream;
  if (stream) {
    const tracks = stream.getTracks();
    tracks.forEach((track) => track.stop());
    video.srcObject = null;
  }
}